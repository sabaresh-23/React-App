import React from "react";
import Header from "./Header";
import Note from "./Note";

function App() {
  return (
    <div>
      <Header />
      <Note />
    </div>
  );
}

export default App;
